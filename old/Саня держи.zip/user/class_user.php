<?php
class User {
	public $login;
	public $name;
	public $id;
	public $type;
	public $path;
}
?>
