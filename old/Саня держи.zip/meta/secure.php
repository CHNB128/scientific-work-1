<?php
define("HASH_TYPE",         "ripemd160");
define("SECRET_ACCESS_KEY", "iloveyou");
define("COOKIE_ACCESS_NAME","t_f_13");
define("COOKIE_LIFE_TIME",  time() + (86400 * 30)); // one day
?>
