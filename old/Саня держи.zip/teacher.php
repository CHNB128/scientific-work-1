<html>
  <head>
    <title>Untitled</title>
  </head>
  <body>
	  <div>
		  <table border="1px" width="300">
			  <caption>Задания надом</caption>
			<tr><th>группа</th><th>задание</th><th>срок</th></tr>
            <tr><td>1</td><td>1</td><td>1</td></tr>
            <tr><td>2</td><td>2</td><td>2</td></tr>
            <tr><td>3</td><td>3</td><td>3</td></tr>
		  </table>
	  </div>
	  <div>
		  <select multiple name="";
			  <option>
			  
	  </div>
	  
  </body>
</html>
