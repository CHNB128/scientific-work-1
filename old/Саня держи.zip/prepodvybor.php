<!DOCTYPE html>
<html lang="en">
<head>
	<style type="text/css">
		h3 {
			text-align: center;
			font-size: 30pt;
		}
		h2 {
			text-align: center;
			font-size: 25pt;
			color: #09539e;
		}
		.but {
			display: flex;
			flex-direction: row;
			margin-top: 15%;
			margin-left: 16%;

		}
	    button {
	    	width: 250px;
	    	margin-left: 140px;
	    	height: 70px;
	    	font-size: 15pt;
	    	border-radius: 10px;
	    }
	    a :hover {
	    	background-color: #09539e;
			transition: 0.7s;
	    }
	</style>
	<meta charset="UTF-8">
	<title>Document</title>
	
</head>
<body>
	<div class="but">
	<a href="prepod2.php"><button>Дать домашнее задание</button></a>
	<a href="prepod4.php"><button>Проверить домашнее задание</button></a>
	</div>
</body>
</html>