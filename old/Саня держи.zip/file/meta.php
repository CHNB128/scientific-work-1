<?php
define("MAX_FILE_SIZE", 500000);
?>
