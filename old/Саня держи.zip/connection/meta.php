<?php
define("DB_SERVER", 	"srv-pleskdb28.ps.kz:3306");
define("DB_USER", 		"diplo_almty2016");
define("DB_PASSWORD", "almty2016");
define("DB_NAME", 		"diplomk1_diplomk1");
define("DB_CHARSET", 	"utf8");
?>
