<?php
echo 'student';