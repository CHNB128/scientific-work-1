<?php
echo 'teacher';