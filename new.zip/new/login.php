<?php
require_once "connection.php";

$query = <<<<EOT
  SELECT type_id
  FROM users
	WHERE login=$_POST['login']
	AND	password=$_POST['password']
  LIMIT 1'
EOT;

$user_data = $mysqli->query($query)->fetch_assoc();

if($user_data) {
	session_start();
  $_SESSION['login'] = $user_data['login'];
  $_SESSION['type'] = $user_data['type'];
  switch ($user_data['type']) {
    case 'admin':
      header("Location: /admin.php");
      break;
    case 'student':
      header("Location: /student.php");
      break;
    case 'teacher':
      header("Location: /teacher.php");
      break;    
  }
} else {
  header("Location: /index.php");
}