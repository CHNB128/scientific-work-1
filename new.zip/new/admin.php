<?php
echo 'admin';