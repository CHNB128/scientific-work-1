<?php 
	$mysqli = new mysqli("srv-pleskdb28.ps.kz:3306", "diplo_00", "diplo_00", "diplomk1_00");
?>